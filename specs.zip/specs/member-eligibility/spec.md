# SPEC.md — Member Eligibility Check (Phase 1)
# Location : specs/member-eligibility/spec.md
# Committed : YES
# Status    : DRAFT
# Author    : Kamal Gurnani | Date: 2026-06-23
# Branch    : feature/member-eligibility
#
# PURPOSE: Define WHAT the feature does and WHY — not HOW.
# HOW is answered in PLAN.md.
# EVERY acceptance criterion must trace to a verifiable test.
# Risk classification: specs/member-eligibility/risk-classification.md (Medium)
# ─────────────────────────────────────────────────────────────

---

## 1. Overview

### 1.1 Problem Statement
Non-clinical intake agents creating prior authorization requests cannot verify
whether the selected member is enrolled in the chosen health plan before
submitting the PA request. Requests are submitted blind, causing rework when
plan mismatches are discovered during downstream clinical review.

### 1.2 Proposed Solution
Expose a new `POST /api/eligibility/check` endpoint that accepts a `patientId`
and `healthPlanId`, compares `member.plan_code` against `health_plan.plan_code`
in the local database, and returns ELIGIBLE, INELIGIBLE, or ERROR. The wizard
displays the result inline at step 4 (member selection) immediately after the
agent selects a member. The check is advisory — the agent may proceed with PA
creation regardless of result. Every check writes one audit record to the
`eligibility_checks` database table.

### 1.3 Success Criteria
All eleven acceptance criteria below pass, `dotnet build` produces zero
warnings, and `/hipaa-check` returns COMPLIANT.

---

## 2. Functional Requirements

### 2.1 Core Behaviour

FR-01: The system shall accept a `patientId` and `healthPlanId` and return one
       of three statuses: ELIGIBLE, INELIGIBLE, or ERROR.

FR-02: The system shall determine ELIGIBLE when the member record exists AND
       `member.plan_code` equals `health_plan.plan_code` (case-sensitive string
       comparison).

FR-03: The system shall determine INELIGIBLE when the member record exists AND
       `member.plan_code` does not match `health_plan.plan_code`, including when
       `member.plan_code` is NULL.

FR-04: The system shall determine ERROR when the member record is not found OR
       the health plan record is not found in the database.

FR-05: The eligibility result shall be advisory only — the system shall not
       prevent the agent from continuing the PA creation wizard regardless of
       result. The wizard "Continue" button remains enabled for all statuses.

FR-06: The system shall write exactly one row to the `eligibility_checks` audit
       table per check, including ERROR outcomes. The row contains
       `correlation_id`, `eligibility_status`, `checked_at`, and `data_source`.
       No PHI fields are stored — no `patient_id`, no `health_plan_id`.
       Traceability is via `correlation_id` only.

FR-07: The system shall generate a `correlationId` (Guid) server-side if one is
       not provided in the request body.

FR-08: No PHI field values (patientId, firstName, lastName, dateOfBirth,
       memberCode, phone, emailAddress, addressLine) shall appear in any
       ILogger call at any log level.

### 2.2 User Flows

**Flow 1 — ELIGIBLE member:**
1. Agent completes wizard step 3 (selects health plan from the radio list).
2. Agent proceeds to step 4 and clicks a member from the SearchSelect dropdown.
3. SearchSelect fires `onSelect` — frontend immediately calls
   `POST /api/eligibility/check` with `patientId` and `healthPlanId`.
4. While the check is in-flight, wizard shows a subtle "Checking eligibility…"
   message below the member chip.
5. System finds member, finds health plan, compares `plan_code` — match found.
6. System writes one audit row to `eligibility_checks`. Returns HTTP 200
   `{ "status": "ELIGIBLE", "correlationId": "...", "errorCode": null, "errorMessage": null }`.
7. Frontend displays a green ELIGIBLE banner below the member chip.
8. Agent proceeds to step 5 (Continue button was never disabled).

**Flow 2 — INELIGIBLE member:**
1–4. Same as Flow 1.
5. System finds member and plan; `plan_code` values do not match (or member
   `plan_code` is NULL).
6. System writes audit row. Returns HTTP 200 with `"status": "INELIGIBLE"`.
7. Frontend displays an amber INELIGIBLE warning banner below the member chip.
8. Agent may still click Continue — the wizard is not blocked.

**Flow 3 — ERROR (member or plan not found):**
1–4. Same as Flow 1.
5. System cannot find the member OR cannot find the health plan.
6. System writes audit row (correlation_id + ERROR status, no PHI stored).
   Returns HTTP 200 with `"status": "ERROR"`, `"errorCode"` populated.
7. Frontend displays a red ERROR banner below the member chip with a generic
   message (no PHI, no internal codes exposed to the user).
8. Agent may still click Continue.

**Flow 4 — Member cleared:**
1. Agent clicks "✕" on the member chip (SearchSelect onClear fires).
2. Frontend clears the eligibility result banner.
3. No API call is made on clear.

**Flow 5 — API call itself fails (network/500):**
1. Frontend call to `/api/eligibility/check` returns a non-200 HTTP response
   or throws a network error.
2. Frontend displays a generic amber warning: "Eligibility check unavailable —
   you may still proceed."
3. No audit row is written (the server did not process the request).
4. Continue button remains enabled.

---

## 3. Acceptance Criteria
*Each criterion: testable, binary (pass/fail), observable via Swagger or direct DB query.*

| ID    | Given | When | Then | Verified By |
|-------|-------|------|------|-------------|
| AC-01 | patientId=PT001234 (plan_code=CIGNA), healthPlanId=1 (Cigna Health, plan_code=CIGNA) | POST /api/eligibility/check | HTTP 200; body `status`="ELIGIBLE"; `correlationId` is a non-empty GUID; `errorCode`=null | Swagger |
| AC-02 | patientId=PT001234 (plan_code=CIGNA), healthPlanId=2 (Aetna, plan_code=AETNA) | POST /api/eligibility/check | HTTP 200; body `status`="INELIGIBLE"; `errorCode`=null | Swagger |
| AC-03 | patientId=PT001240 (plan_code=NULL), healthPlanId=1 (Cigna Health, plan_code=CIGNA) | POST /api/eligibility/check | HTTP 200; body `status`="INELIGIBLE" | Swagger |
| AC-04 | patientId="PT999999" (does not exist), healthPlanId=1 (valid) | POST /api/eligibility/check | HTTP 200; body `status`="ERROR"; `errorCode`="ERR-MBR-001" | Swagger |
| AC-05 | patientId=PT001234 (valid), healthPlanId=99999 (does not exist) | POST /api/eligibility/check | HTTP 200; body `status`="ERROR"; `errorCode`="ERR-PLAN-001" | Swagger |
| AC-06 | Request body missing `patientId` or `healthPlanId` | POST /api/eligibility/check | HTTP 400; zero rows inserted in `eligibility_checks` for this attempt | Swagger + Direct DB query |
| AC-07 | Request body omits `correlationId` | POST /api/eligibility/check | HTTP 200; response `correlationId` is a system-generated valid GUID | Swagger |
| AC-08 | Request body includes `correlationId`="aaaaaaaa-0000-0000-0000-000000000001" | POST /api/eligibility/check | HTTP 200; response `correlationId` equals "aaaaaaaa-0000-0000-0000-000000000001" (echoed unchanged) | Swagger |
| AC-09 | Any of AC-01 through AC-05 executes | POST /api/eligibility/check | Exactly one row inserted in `eligibility_checks` with matching `correlation_id` and `eligibility_status`; `checked_at` is populated | Direct DB query |
| AC-10 | Any code path that handles an eligibility check runs | Application running | No PHI field value (patientId, firstName, lastName, dateOfBirth, memberCode, phone, emailAddress) appears in any ILogger call | /hipaa-check COMPLIANT |
| AC-11 | All code changes applied | `dotnet build` is run | Zero errors, zero warnings | Build output |

---

## 4. API Contract

### 4.1 Endpoint
```
POST /api/eligibility/check
Content-Type: application/json
```
Controller: `EligibilityController` (singular — matches `/api/eligibility/check`
route explicitly shown in CLAUDE.md. This is intentional: "eligibility" is a
concept, not a countable resource, so the standard plural `[Domain]s` convention
does not apply here.)

### 4.2 Request Schema
```json
{
  "patientId": "PT001234",
  "healthPlanId": 1,
  "correlationId": "3fa85f64-5717-4562-b3fc-2c963f66afa6"
}
```

| Field | Type | Required | Validation | Notes |
|-------|------|----------|------------|-------|
| patientId | string | Yes | Non-empty string | Maps to `members.patient_id` |
| healthPlanId | int | Yes | > 0 | Maps to `health_plans.health_plan_id` |
| correlationId | string (GUID) | No | Valid GUID format if provided; HTTP 400 if present but invalid | Server generates `Guid.NewGuid()` if absent |

### 4.3 Response Schema
```json
{
  "status": "ELIGIBLE",
  "correlationId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "errorCode": null,
  "errorMessage": null
}
```

| Field | Type | Notes |
|-------|------|-------|
| status | string | "ELIGIBLE" \| "INELIGIBLE" \| "ERROR" — always present |
| correlationId | string (GUID) | Echoed from request if provided; server-generated if absent |
| errorCode | string \| null | Null when status ≠ ERROR. "ERR-MBR-001" = member not found; "ERR-PLAN-001" = health plan not found |
| errorMessage | string \| null | Null when status ≠ ERROR. Human-readable, generic — contains no PHI and no internal codes |

### 4.4 Error Responses

| HTTP Status | Trigger | Notes |
|-------------|---------|-------|
| 200 | ELIGIBLE, INELIGIBLE, or ERROR result | All three are business outcomes; HTTP status reflects request processing, not eligibility result |
| 400 | Missing required field OR malformed `correlationId` GUID | Standard model validation; no audit row written |
| 500 | Unhandled internal error (e.g. DB unavailable) | Generic message returned; no PHI; no stack trace |

---

## 5. Non-Functional Requirements

| Category | Requirement |
|----------|-------------|
| Performance | Response time < 500ms under normal DB load (local lookup only — two point queries) |
| Security | No PHI field values in any ILogger call at any log level |
| Compliance | One `eligibility_checks` row per check; row contains `correlation_id`, `eligibility_status`, `checked_at`, `data_source`; no PHI stored — traceability via `correlation_id` only |
| Reliability | DB unavailability returns HTTP 500 with generic message — does not silently return ELIGIBLE |
| Observability | `correlationId` echoed in response allows cross-referencing the API response with the audit row |

---

## 6. Constraints
*Derived from CLAUDE.md*

1. No modification to existing entities, DTOs, or controllers — this feature is additive only.
2. New endpoint follows `/api/[controller]/[action]` route convention: `POST /api/eligibility/check`.
3. All new services registered as `AddScoped<IInterface, Implementation>()` in `Program.cs`.
4. EF Core LINQ only — no raw SQL.
5. No PHI field values in any `ILogger` call at any log level (CLAUDE.md section 4.1).
6. New DB table `eligibility_checks` added to `database/init.sql` only — `dotnet ef migrations add` is prohibited.
7. New DTO records (`EligibilityCheckRequest`, `EligibilityCheckResponse`) added to `DTOs/Dtos.cs` using positional record syntax.
8. New entity class (`EligibilityCheck`) added to `Models/Entities.cs` with `[Table("eligibility_checks")]` and `[Column("snake_case")]` attributes.
9. No new NuGet packages — EF Core already present is sufficient.
10. Frontend: new TypeScript interfaces mirroring the DTOs added to `frontend/src/types/index.ts`; eligibility API call added to `frontend/src/api/client.ts`.

---

## 7. Non-Goals
*What this spec explicitly does NOT include*

- ❌ Real-time payer API integration — Phase 2 only; Phase 1 is local DB lookup.
- ❌ Blocking PA submission on INELIGIBLE or ERROR — result is advisory; wizard is never blocked.
- ❌ Date-based eligibility — effective dates and termination dates are out of scope.
- ❌ Benefit-level or procedure-specific eligibility — plan-code match only.
- ❌ Caching of eligibility results — every check hits the database.
- ❌ Role-based access control on the eligibility endpoint — not in scope for Phase 1.

---

## 8. Audit Table Schema
*Authoritative schema from design-note.md — overrides the original OQ-01 resolution*

Table name: `eligibility_checks`

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| id | SERIAL | PRIMARY KEY | Consistent with all existing tables |
| correlation_id | VARCHAR(50) | NOT NULL UNIQUE | Supplied by caller or server-generated |
| eligibility_status | VARCHAR(20) | NOT NULL | 'ELIGIBLE', 'INELIGIBLE', or 'ERROR' |
| checked_at | TIMESTAMP | NOT NULL DEFAULT NOW() | Consistent with `created_at` pattern in `authorizations` |
| data_source | VARCHAR(50) | NOT NULL DEFAULT 'LOCAL_DB' | 'LOCAL_DB' in Phase 1; enables Phase 2 to write 'PAYER_API' without schema change |

No `patient_id` column. No `health_plan_id` column. No FK constraints.
Traceability is via `correlation_id` — the same value is echoed in the API response.

---

## 9. Test Data
*Exact seed records that must exist for all ACs to pass*

| patientId | plan_code | Notes | Used by |
|-----------|-----------|-------|---------|
| PT001234 | CIGNA | Existing seed | AC-01, AC-02, AC-05, AC-08 |
| PT001240 | NULL | **Added to init.sql** — `first_name='Test'`, `last_name='NoPlan'`, all other columns NULL; `plan_code` NULL required for AC-03 | AC-03 |
| PT999999 | N/A | Does not exist — no insert needed | AC-04 |

| healthPlanId | plan_code | Name | Notes | Used by |
|--------------|-----------|------|-------|---------|
| 1 | CIGNA | Cigna Health | Existing seed (SERIAL, 1st insert) | AC-01, AC-04, AC-07, AC-08 |
| 2 | AETNA | Aetna Better Health | Existing seed (SERIAL, 2nd insert) | AC-02 |
| 99999 | N/A | Does not exist | No insert needed | AC-05 |

**Note on healthPlanId values:** Health plans use SERIAL PK inserted in this order in
`init.sql`: 1=Cigna, 2=Aetna, 3=UHC, 4=BSCA, 5=Anthem, 6=Molina. These IDs are only
reliable on a freshly initialised database. For non-fresh DBs, retrieve the correct ID
via `GET /api/healthplans` before running ACs.

---

## 10. Open Questions
*All blocking questions resolved. Non-blocking questions documented with resolutions.*

| ID | Question | Tag | Resolution | Status |
|----|----------|-----|------------|--------|
| OQ-01 | Audit table schema and ERROR-case behaviour | BLOCKING | **RESOLVED** — Table: `eligibility_checks`. Columns: `id` (SERIAL PK), `correlation_id` (VARCHAR NOT NULL UNIQUE), `eligibility_status` (VARCHAR NOT NULL), `checked_at` (TIMESTAMP NOT NULL DEFAULT NOW()), `data_source` (VARCHAR NOT NULL DEFAULT 'LOCAL_DB'). No `patient_id`, no `health_plan_id` — PHI not stored (design-note.md is authoritative). Traceability via `correlation_id` only. See Section 8. | RESOLVED |
| OQ-02 | HTTP status for ERROR outcome | BLOCKING | **RESOLVED** — HTTP 200 for all three statuses. Consistent with existing controller pattern: HTTP errors (400, 404, 500) reflect request/infrastructure failures; business outcomes (ELIGIBLE/INELIGIBLE/ERROR) are all successful responses to a valid request. | RESOLVED |
| OQ-03 | Trigger mechanism — auto vs explicit button | BLOCKING | **RESOLVED** — Auto-trigger on member selection. SearchSelect fires `onSelect(item)` exactly once via `onMouseDown` when user clicks a result — a clean single event, not a keystroke. Frontend calls the API immediately in that handler. Avoids debounce complexity. Derived from SearchSelect.tsx `pick()` implementation. | RESOLVED |
| OQ-04 | UI display location and visual style | BLOCKING | **RESOLVED** — Inline colored banner rendered immediately below the SearchSelect component on step 4, after member chip appears. Uses existing STATUS_COLORS / STATUS_BG palette: ELIGIBLE=green (#dcfce7/#166534), INELIGIBLE=amber (#fef3c7/#b45309), ERROR=red (#fee2e2/#991b1b). Loading state shows "Checking eligibility…" in muted text. Derived from existing color system in types/index.ts. | RESOLVED |
| OQ-05 | correlationId transport — body vs header | NON-BLOCKING | **RESOLVED** — Optional field in request body. Consistent with all existing request DTOs which are plain JSON objects with no custom headers. | RESOLVED |
| OQ-06 | No seed member with plan_code=NULL | NON-BLOCKING | **RESOLVED** — Add PT001240 with NULL plan_code to init.sql seed data. Required for AC-03 to be executable via Swagger. | RESOLVED |
| OQ-07 | Frontend behaviour when API call itself fails | NON-BLOCKING | **RESOLVED** — Show generic amber warning "Eligibility check unavailable — you may still proceed." Continue button stays enabled (advisory-only FR-05). No audit row written on network failure. Documented in Flow 5 above. | RESOLVED |
| OQ-08 | Response verbosity — include plan_code detail? | NON-BLOCKING | **RESOLVED** — Status only. No `memberPlanCode` or `healthPlanCode` in response. Keeps contract minimal and avoids exposing internal plan codes through the API. | RESOLVED |
| OQ-09 | Specific errorCode values | NON-BLOCKING | **RESOLVED** — "ERR-MBR-001" when member not found; "ERR-PLAN-001" when health plan not found. Distinct codes to distinguish the two ERROR sub-cases without exposing PHI in the code itself. | RESOLVED |
