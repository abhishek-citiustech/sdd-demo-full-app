# TASKS.md — Member Eligibility Check (Phase 1)
# Location : specs/member-eligibility/tasks.md
# Committed : YES
# Status    : READY
# Author    : Kamal Gurnani | Date: 2026-06-23
# Depends on: plan.md DRAFT
#
# PURPOSE: Dependency-ordered, executable task list.
#          Each task is small enough for one Claude Code session.
#          Each task has a clear done condition.
#          Execute in order — complete and mark [x] before starting next.
#
# RULES:
#   - Never skip a task
#   - Never combine tasks from different phases
#   - Mark [x] when done before starting the next task
#   - Run /spec-review after every phase
#   - Run /hipaa-check after Phase 3
#
# SOURCE FILES (read before implementing any task):
#   specs/member-eligibility/spec.md
#   specs/member-eligibility/plan.md
#   specs/member-eligibility/design-note.md
# ─────────────────────────────────────────────────────────────

---

## Progress

- Phase 0 — Pre-flight         : [x] DONE
- Phase 1 — Model Layer        : [x] DONE
- Phase 2 — Data Layer         : [x] DONE
- Phase 3 — Controller + DB    : [~] IN PROGRESS — Tasks 3.1/3.2/3.3 done; Task 3.4 (DB reset) pending
- Phase 4 — Frontend           : [ ] Not started
- Phase 5 — Verification       : [~] AC-11 verified (dotnet build 0 errors 0 warnings)

---

## Phase 0 — Pre-flight
*Must complete before writing any code.*
*These are corrections and confirmations required by design-note.md.*

---

### Task 0.1 — Correct spec.md Section 8 — Audit Table Schema
**File:** `specs/member-eligibility/spec.md`
**Why:** design-note.md (Open Questions table) overrides the OQ-01 resolution
in spec.md. spec.md Section 8 incorrectly includes `patient_id` and
`health_plan_id` columns in the audit table. plan.md Section 3.3 defines
the authoritative schema without those columns.

**Action:** Replace Section 8 in spec.md with the schema from plan.md Section 3.3:

```
Table: eligibility_checks

| Column             | Type         | Constraints                |
|--------------------|--------------|----------------------------|
| id                 | SERIAL       | PRIMARY KEY                |
| correlation_id     | VARCHAR(50)  | NOT NULL UNIQUE             |
| eligibility_status | VARCHAR(20)  | NOT NULL                   |
| checked_at         | TIMESTAMP    | NOT NULL DEFAULT NOW()      |
| data_source        | VARCHAR(50)  | NOT NULL DEFAULT 'LOCAL_DB' |

No patient_id column. No health_plan_id column.
No FK constraints — standalone audit table.
```

Also update OQ-01 resolution text in Section 10 to reference the design-note
as the authoritative source and note patient_id/health_plan_id are excluded.

**Done when:** spec.md Section 8 contains only the five columns above. No
mention of patient_id or health_plan_id in that section.
**AC covered:** AC-09 (audit row schema)
**Status:** [x] Done — also corrected FR-06, Section 5 NFR, Flow 3, OQ-01

---

### Task 0.2 — Confirm AC-03 healthPlanId
**File:** `specs/member-eligibility/spec.md`
**Why:** sdd-clarify report noted AC-03 "any valid healthPlanId" is
under-specified. All other ACs use a concrete ID.

**Action:** In Section 3, AC-03, replace "any valid healthPlanId" with
"healthPlanId=1 (Cigna Health)".

**Done when:** AC-03 Given reads:
`patientId=PT001240 (plan_code=NULL), healthPlanId=1 (Cigna Health, plan_code=CIGNA)`
**AC covered:** AC-03
**Status:** [x] Done

---

### Task 0.3 — Add PT001240 full column values to spec.md Section 9
**File:** `specs/member-eligibility/spec.md`
**Why:** sdd-clarify report noted PT001240 seed row lacks required column
values (first_name, last_name are NOT NULL in the members table).

**Action:** In Section 9 (Test Data), update the PT001240 row to specify:
`first_name='Test', last_name='NoPlan', all other columns NULL`.

**Done when:** Section 9 PT001240 row shows all required column values.
**AC covered:** AC-03
**Status:** [x] Done

**→ Run /spec-review after Phase 0. No FAIL on corrected sections.**

---

## Phase 1 — Model Layer
*No dependencies — start here.*
*Read these files before any task:*
*  `backend/PriorAuth.API/Models/Entities.cs` — entity pattern*
*  `backend/PriorAuth.API/DTOs/Dtos.cs` — DTO record pattern*

---

### Task 1.1 — Add EligibilityCheck Entity
**File:** `backend/PriorAuth.API/Models/Entities.cs`
**Pattern reference:** `HealthPlan` class in the same file — `[Table]`,
`[Key, Column]`, `[Column]`, nullable `?` suffix, `= string.Empty` defaults.

**Action:** Append the following class at the end of the file, after all
existing entity classes:

```csharp
[Table("eligibility_checks")]
public class EligibilityCheck
{
    [Key, Column("id")]
    public int Id { get; set; }

    [Column("correlation_id")]
    public string CorrelationId { get; set; } = string.Empty;

    [Column("eligibility_status")]
    public string EligibilityStatus { get; set; } = string.Empty;

    [Column("checked_at")]
    public DateTime CheckedAt { get; set; }

    [Column("data_source")]
    public string DataSource { get; set; } = "LOCAL_DB";
}
```

**Constraints:**
- No navigation properties
- No FK attributes — standalone audit entity (plan.md Section 3.1)
- No changes to any existing class in this file

**Done when:** `cd backend/PriorAuth.API && dotnet build` passes with zero
errors and zero warnings.
**AC covered:** AC-09 (entity required for audit row write)
**Status:** [x] Done

---

### Task 1.2 — Add EligibilityCheckRequest DTO
**File:** `backend/PriorAuth.API/DTOs/Dtos.cs`
**Pattern reference:** `CreateAuthorizationRequest` record in the same file —
positional record syntax, nullable `?` for optional fields.

**Action:** Append the following record at the end of the file:

```csharp
public record EligibilityCheckRequest(
    string PatientId,
    int HealthPlanId,
    string? CorrelationId
);
```

**Constraints:**
- Positional order is fixed — matches JSON field order in spec.md Section 4.2
- `CorrelationId` is nullable (`string?`) — optional in request body
- No changes to any existing record in this file

**Done when:** `dotnet build` passes with zero errors and zero warnings.
**AC covered:** AC-06 (required fields PatientId, HealthPlanId),
AC-07 (optional CorrelationId), AC-08 (CorrelationId echo)
**Status:** [x] Done

---

### Task 1.3 — Add EligibilityCheckResponse DTO
**File:** `backend/PriorAuth.API/DTOs/Dtos.cs`
**Pattern reference:** Same file — positional record, nullable `string?` fields.

**Action:** Append the following record immediately after `EligibilityCheckRequest`:

```csharp
public record EligibilityCheckResponse(
    string Status,
    string CorrelationId,
    string? ErrorCode,
    string? ErrorMessage
);
```

**Constraints:**
- Positional order is fixed — matches spec.md Section 4.3 response schema
- `ErrorCode` and `ErrorMessage` are nullable — null when status ≠ ERROR
- No changes to any existing record in this file

**Done when:** `dotnet build` passes with zero errors and zero warnings.
**AC covered:** AC-01 (status=ELIGIBLE, errorCode=null), AC-02 (INELIGIBLE),
AC-04 (errorCode=ERR-MBR-001), AC-05 (errorCode=ERR-PLAN-001)
**Status:** [x] Done

**→ Run /spec-review after Phase 1.**

---

## Phase 2 — Data Layer
*Depends on: Phase 1 complete (EligibilityCheck class must exist to compile).*
*Read this file before starting:*
*  `backend/PriorAuth.API/Data/PriorAuthDbContext.cs` — DbSet pattern*

---

### Task 2.1 — Register EligibilityCheck in DbContext
**File:** `backend/PriorAuth.API/Data/PriorAuthDbContext.cs`
**Pattern reference:** Existing `DbSet` properties in the same file, e.g.
`public DbSet<HealthPlan> HealthPlans => Set<HealthPlan>();`

**Action:** Add one property inside the `PriorAuthDbContext` class body,
alongside the existing DbSet declarations:

```csharp
public DbSet<EligibilityCheck> EligibilityChecks => Set<EligibilityCheck>();
```

**Constraints:**
- One line only — no other changes to this file
- No `OnModelCreating` configuration needed — `EligibilityCheck` has no FK
  relationships (plan.md Section 3.1: "No OnModelCreating configuration required")
- Do not modify any existing DbSet property or OnModelCreating configuration

**Done when:** `dotnet build` passes with zero errors and zero warnings.
**AC covered:** AC-09 (EF can write to eligibility_checks via SaveChangesAsync)
**Status:** [x] Done

**→ Run /spec-review after Phase 2.**

---

## Phase 3 — Controller and Database
*Depends on: Phases 1 and 2 complete.*
*Tasks 3.1, 3.2, and 3.3 have no inter-dependency — they may be done in any order.*
*Task 3.4 depends on 3.1 + 3.2 + 3.3 all complete.*
*Read these files before starting:*
*  `backend/PriorAuth.API/Controllers/AuthorizationsController.cs` — controller structure,*
*  ILogger usage, FindAsync pattern, SaveChangesAsync, Ok() return*
*  `database/init.sql` — table DDL pattern and INSERT pattern*

---

### Task 3.1 — Create EligibilityController
**File:** `backend/PriorAuth.API/Controllers/EligibilityController.cs` ← NEW FILE
**Pattern reference:** `AuthorizationsController.cs` — `[ApiController]`,
`[Route("api/[controller]")]`, constructor injection, `FindAsync`, `Ok()`,
`BadRequest()`, `ILogger.LogInformation`.

**Action:** Create new file with the following exact content:

```csharp
using Microsoft.AspNetCore.Mvc;
using PriorAuth.API.Data;
using PriorAuth.API.DTOs;
using PriorAuth.API.Models;

namespace PriorAuth.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class EligibilityController : ControllerBase
{
    private readonly PriorAuthDbContext _db;
    private readonly ILogger<EligibilityController> _logger;

    public EligibilityController(PriorAuthDbContext db, ILogger<EligibilityController> logger)
    {
        _db = db;
        _logger = logger;
    }

    [HttpPost("check")]
    public async Task<ActionResult<EligibilityCheckResponse>> Check(
        [FromBody] EligibilityCheckRequest request)
    {
        if (!string.IsNullOrEmpty(request.CorrelationId) &&
            !Guid.TryParse(request.CorrelationId, out _))
            return BadRequest("CorrelationId must be a valid GUID.");

        var correlationId = !string.IsNullOrEmpty(request.CorrelationId)
            ? request.CorrelationId
            : Guid.NewGuid().ToString();

        var member = await _db.Members.FindAsync(request.PatientId);
        var plan   = await _db.HealthPlans.FindAsync(request.HealthPlanId);

        string  status;
        string? errorCode    = null;
        string? errorMessage = null;

        if (member == null)
        {
            status       = "ERROR";
            errorCode    = "ERR-MBR-001";
            errorMessage = "Member not found.";
        }
        else if (plan == null)
        {
            status       = "ERROR";
            errorCode    = "ERR-PLAN-001";
            errorMessage = "Health plan not found.";
        }
        else
        {
            // member.PlanCode == null is always INELIGIBLE (spec FR-03)
            // Guard prevents null == null from returning ELIGIBLE
            status = (member.PlanCode != null && member.PlanCode == plan.PlanCode)
                ? "ELIGIBLE"
                : "INELIGIBLE";
        }

        _db.EligibilityChecks.Add(new EligibilityCheck
        {
            CorrelationId     = correlationId,
            EligibilityStatus = status,
            CheckedAt         = DateTime.UtcNow,
            DataSource        = "LOCAL_DB"
        });
        await _db.SaveChangesAsync();

        _logger.LogInformation("Eligibility check: {CorrelationId} → {Status}",
            correlationId, status);

        return Ok(new EligibilityCheckResponse(status, correlationId, errorCode, errorMessage));
    }
}
```

**Constraints (verify before marking done):**
- No PHI in any ILogger call — only `correlationId` and `status` are logged
- No `patient_id`, `health_plan_id`, member name, or plan code in the audit row
- Single `SaveChangesAsync` call — audit write is atomic with the check
- `member.PlanCode != null` guard applied before equality (plan.md Section 4.2)
- No Program.cs change needed — controller auto-discovered by `AddControllers()`

**Done when:** `dotnet build` passes with zero errors and zero warnings.
**AC covered:** AC-01 (ELIGIBLE), AC-02 (INELIGIBLE), AC-03 (NULL plan_code),
AC-04 (ERR-MBR-001), AC-05 (ERR-PLAN-001), AC-06 (HTTP 400),
AC-07 (auto-generate correlationId), AC-08 (echo correlationId), AC-09 (audit row)
**Status:** [x] Done

---

### Task 3.2 — Add eligibility_checks Table to init.sql
**File:** `database/init.sql`
**Pattern reference:** `CREATE TABLE authorization_procedures` in the same
file — SERIAL PK, snake_case column names, VARCHAR with lengths, NOT NULL,
DEFAULT expressions.

**Action:** Insert the following DDL block after the `CREATE TABLE authorizations`
block and before the `-- SEED DATA` comment:

```sql
CREATE TABLE eligibility_checks (
    id                 SERIAL       PRIMARY KEY,
    correlation_id     VARCHAR(50)  NOT NULL UNIQUE,
    eligibility_status VARCHAR(20)  NOT NULL,
    checked_at         TIMESTAMP    NOT NULL DEFAULT NOW(),
    data_source        VARCHAR(50)  NOT NULL DEFAULT 'LOCAL_DB'
);
```

**Constraints:**
- No FK constraints — no REFERENCES clause (plan.md Section 3.3)
- No patient_id column. No health_plan_id column.
- Do not modify any existing CREATE TABLE statement

**Done when:** File saved. Verified by inspection — five columns only.
**AC covered:** AC-09 (table must exist for audit row insert)
**Status:** [x] Done

---

### Task 3.3 — Add PT001240 Seed Member to init.sql
**File:** `database/init.sql`
**Pattern reference:** Existing `INSERT INTO members VALUES` block in the
same file — column order: patient_id, first_name, last_name, then all
nullable columns.

**Action:** Append one row to the existing `INSERT INTO members VALUES` block.
The members table has NOT NULL constraints on `first_name` and `last_name`
only — all other columns may be NULL (plan.md Section 3.4, spec.md Section 9).

```sql
-- Add as the last row in the INSERT INTO members block:
('PT001240', 'Test', 'NoPlan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
```

Column order: patient_id, first_name, last_name, date_of_birth, gender,
language_code, address_line1, address_line2, city, state, zip_code, phone,
email_address, member_code, group_number, ipa_code, plan_code.
`plan_code` (last column) = NULL — required for AC-03.

**Constraints:**
- Do not modify any existing INSERT row
- Verify column count matches existing member rows (17 columns)

**Done when:** File saved. PT001240 row present with plan_code = NULL (17th value).
**AC covered:** AC-03 (INELIGIBLE when member plan_code is NULL)
**Status:** [x] Done

---

### Task 3.4 — Reset Database and Verify Backend Starts
*Depends on: Tasks 3.1, 3.2, and 3.3 all complete.*

**Action:**
1. Stop any running backend process.
2. Drop and recreate the database, re-running `database/init.sql`:
   ```
   docker-compose down -v
   docker-compose up -d
   ```
   Or for local PostgreSQL: drop and recreate `priorauth`, then run init.sql.
3. Start backend: `cd backend/PriorAuth.API && dotnet run`
4. Open `http://localhost:5000/swagger`
5. Confirm `POST /api/eligibility/check` endpoint appears in Swagger UI.

**Done when:** Swagger UI shows `POST /api/eligibility/check` with the correct
request/response schema. Backend starts with zero startup errors.
**AC covered:** Foundational — all ACs depend on the endpoint being reachable.
**Status:** [ ] Done

**→ Run /hipaa-check. Must return COMPLIANT before Phase 4.**
**→ Run /spec-review after Phase 3. All backend ACs (AC-01 through AC-11) should show PASS or GAP.**

---

## Phase 4 — Frontend
*Depends on: Phase 3 complete and backend running on http://localhost:5000.*
*Read these files before any task:*
*  `frontend/src/types/index.ts` — interface pattern*
*  `frontend/src/api/client.ts` — api object structure and post<T> helper*
*  `frontend/src/pages/NewAuthorizationPage.tsx` — step 4 current implementation*

---

### Task 4.1 — Add TypeScript Interfaces
**File:** `frontend/src/types/index.ts`
**Pattern reference:** `CreateAuthorizationRequest` and `AuthorizationDetail`
interfaces in the same file — camelCase field names, `| null` for nullable
fields, `?` for optional fields.

**Action:** Append the following two interfaces at the end of the file,
after the `STATUS_BG` constant:

```typescript
export interface EligibilityCheckRequest {
  patientId: string;
  healthPlanId: number;
  correlationId?: string;
}

export interface EligibilityCheckResponse {
  status: 'ELIGIBLE' | 'INELIGIBLE' | 'ERROR';
  correlationId: string;
  errorCode: string | null;
  errorMessage: string | null;
}
```

**Constraints:**
- Field names are camelCase — match backend DTO positional parameter names
- `correlationId` is optional (`?`) in request — not required per spec.md 4.2
- `errorCode` and `errorMessage` use `| null` (not `?`) — always present in
  response body, just null-valued when status ≠ ERROR
- No changes to any existing interface or constant

**Done when:** `cd frontend && npm run build` passes with zero TypeScript errors.
**AC covered:** AC-01 through AC-08 (type shapes required for frontend API call)
**Status:** [ ] Done

---

### Task 4.2 — Add Eligibility Method to API Client
**File:** `frontend/src/api/client.ts`
**Pattern reference:** `authorizations.create` in the same file —
`post<ResponseType>('/path', body)` pattern, `BASE = '/api'` prefix omitted.

**Action:** Two changes to this file:

**1. Add to the import statement at the top:**
```typescript
// Extend the existing import from '../types' to include:
import type {
  ..., // existing imports unchanged
  EligibilityCheckRequest,
  EligibilityCheckResponse,
} from '../types';
```

**2. Add `eligibility` property to the `api` object, after `authorizations`:**
```typescript
eligibility: {
  check: (req: EligibilityCheckRequest) =>
    post<EligibilityCheckResponse>('/eligibility/check', req),
},
```

**Constraints:**
- Path is `/eligibility/check` — `BASE = '/api'` is prepended by the
  `post<T>` helper, yielding the full URL `/api/eligibility/check`
- No changes to any existing method or namespace in the api object

**Done when:** `npm run build` passes with zero TypeScript errors.
**AC covered:** AC-01 through AC-08 (frontend can call the endpoint)
**Status:** [ ] Done

---

### Task 4.3 — Modify NewAuthorizationPage Step 4
**File:** `frontend/src/pages/NewAuthorizationPage.tsx`
**Pattern reference:** Existing `useState` declarations at the top of the
component; existing step 4 `SearchSelect` usage (lines 253–269 of current file).

**Action:** Four targeted changes — read the current file before editing.

**Change A — Add import for new types (extend existing import from '../types'):**
```typescript
import type {
  WizardState, Member, Provider, HealthPlan,
  Site, DiagnosisCode, ProcedureCode,
  EligibilityCheckResponse,          // ← add this
} from '../types'
```

**Change B — Add three state variables** alongside existing `useState`
declarations (after `healthPlansLoaded` state):
```typescript
const [eligibilityResult, setEligibilityResult] =
  useState<EligibilityCheckResponse | null>(null)
const [eligibilityLoading, setEligibilityLoading] = useState(false)
const [eligibilityFailed,  setEligibilityFailed]  = useState(false)
```

**Change C — Replace step 4 `onSelect` and `onClear` lambdas:**
```typescript
// Replace:
onSelect={m => setState(s => ({ ...s, member: m }))}
onClear={() => setState(s => ({ ...s, member: null }))}

// With:
onSelect={m => {
  setState(s => ({ ...s, member: m }))
  setEligibilityResult(null)
  setEligibilityFailed(false)
  setEligibilityLoading(true)
  api.eligibility.check({
    patientId: m.patientId,
    healthPlanId: state.healthPlan!.healthPlanId,
  })
    .then(result => setEligibilityResult(result))
    .catch(() => setEligibilityFailed(true))
    .finally(() => setEligibilityLoading(false))
}}
onClear={() => {
  setState(s => ({ ...s, member: null }))
  setEligibilityResult(null)
  setEligibilityFailed(false)
  setEligibilityLoading(false)
}}
```

**Change D — Add eligibility banner JSX** immediately after the closing tag
of the `SearchSelect` component inside the `{step === 4 && (...)}` block:
```tsx
{eligibilityLoading && (
  <div className="text-sm text-muted mt-2">Checking eligibility…</div>
)}
{!eligibilityLoading && eligibilityFailed && (
  <div style={{
    marginTop: 8, padding: '8px 12px', borderRadius: 6,
    backgroundColor: '#fef3c7', color: '#b45309', fontSize: 13
  }}>
    Eligibility check unavailable — you may still proceed.
  </div>
)}
{!eligibilityLoading && eligibilityResult && (
  <div style={{
    marginTop: 8, padding: '8px 12px', borderRadius: 6,
    backgroundColor: eligibilityResult.status === 'ELIGIBLE'   ? '#dcfce7'
                   : eligibilityResult.status === 'INELIGIBLE' ? '#fef3c7'
                   : '#fee2e2',
    color: eligibilityResult.status === 'ELIGIBLE'   ? '#166534'
         : eligibilityResult.status === 'INELIGIBLE' ? '#b45309'
         : '#991b1b',
    fontSize: 13
  }}>
    {eligibilityResult.status === 'ELIGIBLE'   &&
      '✓ Member is eligible for this health plan'}
    {eligibilityResult.status === 'INELIGIBLE' &&
      '⚠ Member plan does not match the selected health plan — you may still proceed'}
    {eligibilityResult.status === 'ERROR'      &&
      '✕ Eligibility could not be verified — you may still proceed'}
  </div>
)}
```

**Colors source:** `STATUS_BG.APPROVED` (#dcfce7) / `STATUS_COLORS.APPROVED`
(#166534) for ELIGIBLE; `STATUS_BG.PENDING` (#fef3c7) / `STATUS_COLORS.PENDING`
(#b45309) for INELIGIBLE and unavailable; `STATUS_BG.DENIED` (#fee2e2) /
`STATUS_COLORS.DENIED` (#991b1b) for ERROR. (plan.md Section 5.4)

**Constraints:**
- `state.healthPlan!.healthPlanId` — non-null assertion safe here: step 4
  is unreachable unless step 3's `canProceed()` passed (requires healthPlan ≠ null)
- `onSelect` callback must remain synchronous (`(item: T) => void`) — async
  work done via `.then()` chain, not `async/await` in the callback directly
- No changes to any other step's JSX
- No changes to `canProceed()`, `next()`, `back()`, or `submit()`
- No new CSS classes — inline styles only (plan.md Section 5.4)

**Done when:** `npm run build` passes with zero TypeScript errors and zero warnings.
**AC covered:** Flows 1–5 from spec.md Section 2.2; advisory behavior (FR-05)
**Status:** [ ] Done

**→ Run /spec-review after Phase 4.**

---

## Phase 5 — Verification
*Run after all implementation phases are complete.*
*Backend running at http://localhost:5000 with fresh DB.*
*Frontend running at http://localhost:5173.*

---

### Task 5.1 — Swagger AC Verification (AC-01 through AC-08)
Open `http://localhost:5000/swagger`. Execute each test case:

| AC | patientId | healthPlanId | correlationId | Expected HTTP | Expected body | Pass? |
|----|-----------|--------------|---------------|---------------|---------------|-------|
| AC-01 | PT001234 | 1 | (omit) | 200 | status="ELIGIBLE", correlationId=non-empty GUID, errorCode=null | [ ] |
| AC-02 | PT001234 | 2 | (omit) | 200 | status="INELIGIBLE", errorCode=null | [ ] |
| AC-03 | PT001240 | 1 | (omit) | 200 | status="INELIGIBLE" | [ ] |
| AC-04 | PT999999 | 1 | (omit) | 200 | status="ERROR", errorCode="ERR-MBR-001" | [ ] |
| AC-05 | PT001234 | 99999 | (omit) | 200 | status="ERROR", errorCode="ERR-PLAN-001" | [ ] |
| AC-06 | (omit) | 1 | (omit) | 400 | validation error | [ ] |
| AC-07 | PT001234 | 1 | (omit) | 200 | correlationId is a valid GUID format | [ ] |
| AC-08 | PT001234 | 1 | aaaaaaaa-0000-0000-0000-000000000001 | 200 | correlationId echoed unchanged | [ ] |

Note on healthPlanId: values 1 and 2 assume a fresh DB where Cigna is the
first SERIAL insert (=1) and Aetna is second (=2). If in doubt, call
`GET /api/healthplans` first to confirm IDs.

**Done when:** All eight rows checked Pass.
**Status:** [ ] Done

---

### Task 5.2 — Audit Row Verification (AC-09)
After running AC-01 through AC-05 in Task 5.1, verify that each produced
exactly one audit row. Connect to the `priorauth` database and run:

```sql
SELECT correlation_id, eligibility_status, checked_at, data_source
FROM eligibility_checks
ORDER BY checked_at DESC;
```

Expected: one row per AC-01–05 run, each with:
- `correlation_id` — non-empty string matching the response
- `eligibility_status` — matches the AC's expected status
- `checked_at` — populated timestamp
- `data_source` — 'LOCAL_DB'

Also verify AC-06 produced zero additional rows (HTTP 400 must not write audit):

```sql
SELECT count(*) FROM eligibility_checks;
-- Must equal exactly the number of AC-01–AC-05 runs performed
```

**Done when:** Row count matches AC executions. All rows have data_source='LOCAL_DB'.
No patient_id column exists in the table.
**AC covered:** AC-09
**Status:** [ ] Done

---

### Task 5.3 — HIPAA Check (AC-10)
```
/hipaa-check
```

Must return: `OVERALL STATUS: COMPLIANT`

If NON-COMPLIANT: inspect the finding, remove any PHI field name from the
flagged ILogger call, re-run `dotnet build`, re-run `/hipaa-check`.

**Done when:** `/hipaa-check` returns COMPLIANT.
**AC covered:** AC-10
**Status:** [ ] Done

---

### Task 5.4 — Build Verification (AC-11)
Run both build checks from CLAUDE.md:

```bash
cd backend/PriorAuth.API && dotnet build
```
Expected: `Build succeeded. 0 Error(s). 0 Warning(s).`

```bash
cd frontend && npm run build
```
Expected: zero TypeScript errors, Vite build output with no errors.

**Done when:** Both commands succeed with zero errors and zero warnings.
**AC covered:** AC-11
**Status:** [ ] Done

---

### Task 5.5 — Fill EVAL.md
**File:** `specs/member-eligibility/eval.md` (create if not present)

Record the following for audit purposes:

```
## Build Output
[paste dotnet build output]
[paste npm run build output]

## AC Results
[paste completed Task 5.1 table]

## Audit Row Evidence
[paste Task 5.2 SQL query output]

## /hipaa-check Result
[paste Task 5.3 output]

## /spec-review Result
[paste /spec-review output]

## Manual Checklist (frontend — not AC-testable via Swagger)
[ ] After INELIGIBLE result: "Continue →" button is clickable
[ ] After ERROR result: "Continue →" button is clickable
[ ] Clicking ✕ on member chip: eligibility banner disappears, no API call
[ ] Simulated network failure: amber "unavailable" warning shown; Continue enabled
[ ] Response received in under 500ms (observe browser Network tab)
```

**Done when:** EVAL.md is committed with all sections populated and manual
checklist items marked.
**Status:** [ ] Done

---

### Task 5.6 — Update CLAUDE.md
**File:** `CLAUDE.md`
**Why:** The eligibility check introduces the first non-resource controller
(singular naming, concept-based route), the first audit-only table (no PHI,
no FK), and the async-in-onSelect pattern. These are new patterns that future
work should follow.

**Action:** Add the following to the API Surface section and Key Patterns:

In **API Surface**, add the new endpoint line:
```
POST /api/eligibility/check  # body: EligibilityCheckRequest
```

In **Key Patterns**, add a new subsection:
```
### Eligibility Controller Pattern
EligibilityController uses singular naming (not plural) because "eligibility"
is a concept, not a countable resource. Route: /api/eligibility/check.
No service class — DbContext injected directly into controller (K2: logic
is three comparisons, does not warrant a service layer).
Audit table (eligibility_checks) stores no PHI — correlationId + status only.
data_source column enables Phase 2 to write 'PAYER_API' without schema change.
```

**Done when:** CLAUDE.md updated and saved.
**Status:** [ ] Done
