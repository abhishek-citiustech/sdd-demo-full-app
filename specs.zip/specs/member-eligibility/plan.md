# PLAN.md — Member Eligibility Check (Phase 1)
# Location : specs/member-eligibility/plan.md
# Committed : YES
# Status    : DRAFT
# Author    : Kamal Gurnani | Date: 2026-06-23
# Depends on: spec.md DRAFT, design-note.md DRAFT
#
# PURPOSE: Define HOW the feature will be built.
#          SPEC.md says what. PLAN.md says how.
#          TASKS.md will break this into executable steps.
#
# CONSTITUTION CHECK: Every decision here must comply with CLAUDE.md.
#   ✓ New files follow naming conventions — CLAUDE.md section 5
#   ✓ Route follows /api/[controller]/[action] — CLAUDE.md section 6
#   ✓ No new service class — PriorAuthDbContext injected directly
#   ✓ EF Core FindAsync only — no raw SQL — CLAUDE.md section 2.1
#   ✓ No PHI in any ILogger call — CLAUDE.md section 4.1
#   ✓ No new NuGet packages — CLAUDE.md section 9
#   ✓ All non-goals from spec.md section 7 are absent from this plan
#
# ⚠ SPEC CORRECTION REQUIRED (before TASKS.md):
#   spec.md Section 8 (audit table) includes patient_id and health_plan_id
#   columns. design-note.md overrides this: neither column is stored.
#   Audit schema authority = design-note.md. Use the schema in Section 3.1
#   of this plan. spec.md Section 8 must be corrected before TASKS.md.
# ─────────────────────────────────────────────────────────────

---

## 1. Technical Approach

The eligibility check is implemented as a single new controller —
`EligibilityController` — with one action method `[HttpPost("check")]`. The
controller injects `PriorAuthDbContext` directly (the same DbContext used by
all existing controllers) and `ILogger<EligibilityController>`. No service
class is created: the check logic is three comparisons and does not warrant
an abstraction layer (design-note.md — K2 Simplicity First).

The backend performs two EF Core point-queries (`FindAsync` on Members and
HealthPlans), compares `plan_code` fields, writes one audit row to
`eligibility_checks`, and returns `EligibilityCheckResponse`. Phase 1 makes
no external calls — local DB only. The audit row contains no PHI: only
`correlation_id`, `eligibility_status`, `checked_at`, and `data_source`
(= `"LOCAL_DB"` in Phase 1).

The frontend extends the existing wizard step 4 (member selection). When
`SearchSelect.onSelect` fires, a `POST /api/eligibility/check` call is made
immediately. An inline colored banner appears below the member chip showing
the result. The wizard is never blocked — the Continue button remains enabled
regardless of status (FR-05).

---

## 2. Files to Change

### 2.1 New Files — Create
| File | Purpose | Pattern reference |
|------|---------|-------------------|
| `backend/PriorAuth.API/Controllers/EligibilityController.cs` | Single action: `POST /api/eligibility/check` | Read `AuthorizationsController.cs` for controller structure, DI injection, and ILogger usage |

### 2.2 Existing Files — Modify
| File | Change | Risk |
|------|--------|------|
| `backend/PriorAuth.API/Models/Entities.cs` | Append `EligibilityCheck` class at end of file | Low — additive only |
| `backend/PriorAuth.API/DTOs/Dtos.cs` | Append `EligibilityCheckRequest` and `EligibilityCheckResponse` records at end of file | Low — additive only |
| `backend/PriorAuth.API/Data/PriorAuthDbContext.cs` | Add one `DbSet<EligibilityCheck>` property | Low — additive only |
| `database/init.sql` | Add `CREATE TABLE eligibility_checks`; add PT001240 member seed row | Low — additive only; existing data unaffected |
| `frontend/src/types/index.ts` | Append `EligibilityCheckRequest` and `EligibilityCheckResponse` interfaces | Low — additive only |
| `frontend/src/api/client.ts` | Add `eligibility` namespace to the `api` object | Low — additive only |
| `frontend/src/pages/NewAuthorizationPage.tsx` | Add 3 state variables; modify step 4 `onSelect` and `onClear`; add eligibility banner JSX | Medium — existing step 4 logic modified |

### 2.3 Files — Do Not Touch
| File | Reason |
|------|--------|
| `backend/PriorAuth.API/Controllers/AuthorizationsController.cs` | Read only — used as structural pattern reference |
| `backend/PriorAuth.API/Controllers/LookupControllers.cs` | Read only — used as structural pattern reference |
| `backend/PriorAuth.API/Program.cs` | No changes needed — `PriorAuthDbContext` already registered as scoped; new controller auto-discovered by `AddControllers()` |
| `frontend/src/components/SearchSelect.tsx` | No changes — `onSelect` callback signature is sufficient |
| `frontend/src/pages/DashboardPage.tsx` | Out of scope |
| `frontend/src/pages/AuthorizationDetailPage.tsx` | Out of scope |

---

## 3. Data Model

### 3.1 New Entity — `EligibilityCheck`

Append to `backend/PriorAuth.API/Models/Entities.cs`:

```csharp
[Table("eligibility_checks")]
public class EligibilityCheck
{
    [Key, Column("id")]
    public int Id { get; set; }

    [Column("correlation_id")]
    public string CorrelationId { get; set; } = string.Empty;

    [Column("eligibility_status")]
    public string EligibilityStatus { get; set; } = string.Empty;

    [Column("checked_at")]
    public DateTime CheckedAt { get; set; }

    [Column("data_source")]
    public string DataSource { get; set; } = "LOCAL_DB";
}
```

No navigation properties. No FK constraints — `EligibilityCheck` is a
standalone audit record. No `OnModelCreating` configuration required.

### 3.2 New DTOs

Append to `backend/PriorAuth.API/DTOs/Dtos.cs`:

```csharp
public record EligibilityCheckRequest(
    string PatientId,
    int HealthPlanId,
    string? CorrelationId
);

public record EligibilityCheckResponse(
    string Status,
    string CorrelationId,
    string? ErrorCode,
    string? ErrorMessage
);
```

Positional order matters — constructors are called positionally everywhere
these records are instantiated (CLAUDE.md pattern).

### 3.3 Database — New Table

Add to `database/init.sql`, after the `authorizations` table DDL and before
the seed data block:

```sql
CREATE TABLE eligibility_checks (
    id                 SERIAL       PRIMARY KEY,
    correlation_id     VARCHAR(50)  NOT NULL UNIQUE,
    eligibility_status VARCHAR(20)  NOT NULL,
    checked_at         TIMESTAMP    NOT NULL DEFAULT NOW(),
    data_source        VARCHAR(50)  NOT NULL DEFAULT 'LOCAL_DB'
);
```

No FK constraints — `patient_id` and `health_plan_id` are intentionally
absent (design-note.md: PHI not stored; traceability via `correlation_id`
only).

### 3.4 New Seed Row — PT001240

Add to `database/init.sql` in the `INSERT INTO members` block:

```sql
INSERT INTO members (patient_id, first_name, last_name) VALUES
('PT001240', 'Test', 'NoPlan');
```

All other columns default to NULL (all are nullable except `patient_id`,
`first_name`, `last_name`). `plan_code` will be NULL — required for AC-03.

### 3.5 DbContext Change

Add one property to `PriorAuthDbContext`. No `OnModelCreating` entry needed.

```csharp
// Add alongside existing DbSet properties
public DbSet<EligibilityCheck> EligibilityChecks => Set<EligibilityCheck>();
```

---

## 4. API Design

### 4.1 Controller

```
File   : Controllers/EligibilityController.cs
Class  : EligibilityController
Route  : [Route("api/[controller]")]   → /api/eligibility
Action : [HttpPost("check")]           → POST /api/eligibility/check
Returns: ActionResult<EligibilityCheckResponse>
Injects: PriorAuthDbContext _db
         ILogger<EligibilityController> _logger
```

`EligibilityController` (singular) is intentional — matches the
`/api/eligibility/check` route shown in CLAUDE.md. "Eligibility" is a
concept, not a countable resource noun, so the `[Domain]s` plural
convention does not apply here (documented in spec.md section 4.1).

### 4.2 Request → Response Flow

```
POST /api/eligibility/check  { patientId, healthPlanId, correlationId? }
  │
  ├─ [ApiController] validates required fields
  │    PatientId missing  → HTTP 400 (no DB touched, no audit row)
  │    HealthPlanId ≤ 0   → HTTP 400 (no DB touched, no audit row)
  │
  ├─ CorrelationId provided?
  │    Yes → Guid.TryParse → invalid format → HTTP 400
  │    Yes → valid         → use as-is
  │    No  → Guid.NewGuid().ToString()
  │
  ├─ member = await _db.Members.FindAsync(request.PatientId)
  │    null → status = "ERROR", errorCode = "ERR-MBR-001"
  │
  ├─ plan = await _db.HealthPlans.FindAsync(request.HealthPlanId)
  │    null → status = "ERROR", errorCode = "ERR-PLAN-001"
  │
  ├─ Both found → compare plan codes:
  │    member.PlanCode != null
  │    AND member.PlanCode == plan.PlanCode  → status = "ELIGIBLE"
  │    otherwise (null or mismatch)          → status = "INELIGIBLE"
  │
  │    ⚠ NULL EDGE CASE: member.PlanCode == null treated as INELIGIBLE
  │    even if plan.PlanCode is also null (FR-03 — null = INELIGIBLE).
  │    Guard: check member.PlanCode != null BEFORE equality comparison.
  │
  ├─ _db.EligibilityChecks.Add(new EligibilityCheck {
  │      CorrelationId    = correlationId,
  │      EligibilityStatus = status,
  │      CheckedAt        = DateTime.UtcNow,
  │      DataSource       = "LOCAL_DB"
  │  })
  │  await _db.SaveChangesAsync()   ← single commit; audit + check atomic
  │
  ├─ _logger.LogInformation(
  │      "Eligibility check: {CorrelationId} → {Status}",
  │      correlationId, status)     ← no PHI logged
  │
  └─ return Ok(new EligibilityCheckResponse(
         status, correlationId, errorCode, errorMessage))
```

### 4.3 Error Handling

| Condition | Error Code | HTTP Status | Response body |
|-----------|------------|-------------|---------------|
| Member not found | ERR-MBR-001 | 200 | `status`="ERROR", `errorCode`="ERR-MBR-001" |
| Health plan not found | ERR-PLAN-001 | 200 | `status`="ERROR", `errorCode`="ERR-PLAN-001" |
| Missing required field | — | 400 | ASP.NET Core default validation response |
| Invalid GUID in `correlationId` | — | 400 | `"CorrelationId must be a valid GUID."` |
| DB unavailable (unhandled exception) | — | 500 | ASP.NET Core default error response — no stack trace, no PHI |

All ERROR-status responses return HTTP 200 — business outcomes are not HTTP
errors (consistent with existing controller patterns in this codebase).

---

## 5. Frontend Plan

### 5.1 New Files
None. All changes are additions to existing files.

### 5.2 TypeScript Types

Append to `frontend/src/types/index.ts`:

```typescript
export interface EligibilityCheckRequest {
  patientId: string;
  healthPlanId: number;
  correlationId?: string;
}

export interface EligibilityCheckResponse {
  status: 'ELIGIBLE' | 'INELIGIBLE' | 'ERROR';
  correlationId: string;
  errorCode: string | null;
  errorMessage: string | null;
}
```

### 5.3 API Client Addition

Add `eligibility` namespace to the `api` object in `frontend/src/api/client.ts`.
Add the new import alongside existing imports at the top:

```typescript
// Add to import list at top of file
import type { ..., EligibilityCheckRequest, EligibilityCheckResponse } from '../types';

// Add inside the api object, after the authorizations namespace
eligibility: {
  check: (req: EligibilityCheckRequest) =>
    post<EligibilityCheckResponse>('/eligibility/check', req),
},
```

`post<T>` is the existing helper — path is relative to `BASE = '/api'`.

### 5.4 NewAuthorizationPage.tsx — Step 4 Changes

**New state variables** (add alongside existing `useState` declarations):

```typescript
const [eligibilityResult, setEligibilityResult] =
  useState<EligibilityCheckResponse | null>(null)
const [eligibilityLoading, setEligibilityLoading] = useState(false)
const [eligibilityFailed, setEligibilityFailed] = useState(false)
```

**Modified `onSelect` for step 4** (replace the current lambda):

```typescript
// Before:
onSelect={m => setState(s => ({ ...s, member: m }))}

// After:
onSelect={m => {
  setState(s => ({ ...s, member: m }))
  setEligibilityResult(null)
  setEligibilityFailed(false)
  setEligibilityLoading(true)
  api.eligibility.check({
    patientId: m.patientId,
    healthPlanId: state.healthPlan!.healthPlanId,
  })
    .then(result => setEligibilityResult(result))
    .catch(() => setEligibilityFailed(true))
    .finally(() => setEligibilityLoading(false))
}}
```

`state.healthPlan` is guaranteed non-null at step 4 — `canProceed()` at
step 3 requires `state.healthPlan !== null` before advancing.

**Modified `onClear` for step 4** (replace the current lambda):

```typescript
// Before:
onClear={() => setState(s => ({ ...s, member: null }))}

// After:
onClear={() => {
  setState(s => ({ ...s, member: null }))
  setEligibilityResult(null)
  setEligibilityFailed(false)
  setEligibilityLoading(false)
}}
```

**Eligibility banner JSX** (add immediately after the `SearchSelect` closing
tag inside the `{step === 4 && (...)}` block):

```tsx
{/* Eligibility result banner */}
{eligibilityLoading && (
  <div className="text-sm text-muted mt-2">Checking eligibility…</div>
)}
{!eligibilityLoading && eligibilityFailed && (
  <div style={{
    marginTop: 8, padding: '8px 12px', borderRadius: 6,
    backgroundColor: '#fef3c7', color: '#b45309', fontSize: 13
  }}>
    Eligibility check unavailable — you may still proceed.
  </div>
)}
{!eligibilityLoading && eligibilityResult && (
  <div style={{
    marginTop: 8, padding: '8px 12px', borderRadius: 6,
    backgroundColor: eligibilityResult.status === 'ELIGIBLE'   ? '#dcfce7'
                   : eligibilityResult.status === 'INELIGIBLE' ? '#fef3c7'
                   : '#fee2e2',
    color: eligibilityResult.status === 'ELIGIBLE'   ? '#166534'
         : eligibilityResult.status === 'INELIGIBLE' ? '#b45309'
         : '#991b1b',
    fontSize: 13
  }}>
    {eligibilityResult.status === 'ELIGIBLE'   && '✓ Member is eligible for this health plan'}
    {eligibilityResult.status === 'INELIGIBLE' && '⚠ Member plan does not match the selected health plan — you may still proceed'}
    {eligibilityResult.status === 'ERROR'      && '✕ Eligibility could not be verified — you may still proceed'}
  </div>
)}
```

Colors are drawn directly from the existing `STATUS_BG` / `STATUS_COLORS`
palette (ELIGIBLE=APPROVED green, INELIGIBLE=PENDING amber, ERROR=DENIED red).
No new CSS classes or constants required.

---

## 6. Dependency Order

```
Step 1: Model Layer
        Entities.cs   — append EligibilityCheck class
        Dtos.cs       — append EligibilityCheckRequest + EligibilityCheckResponse
        No dependencies. Start here. Both edits are independent of each other.
        ↓
Step 2: Data Layer
        PriorAuthDbContext.cs — add DbSet<EligibilityCheck> property
        Depends on: Step 1 (EligibilityCheck class must exist to compile)
        ↓
Step 3: Backend — parallel tasks (no inter-dependency)
        ├─ EligibilityController.cs — new file
        │   Depends on: Steps 1+2 (DTOs + DbSet must exist)
        └─ database/init.sql — add table DDL + PT001240 seed row
            No code dependency; can run anytime before testing
        ↓
Step 4: Frontend
        types/index.ts        — add EligibilityCheckRequest + EligibilityCheckResponse
        api/client.ts         — add eligibility namespace
        NewAuthorizationPage  — state + onSelect + onClear + banner JSX
        Depends on: Step 3 (endpoint must exist to test end-to-end)
        types/index.ts and api/client.ts edits are independent of each other
        NewAuthorizationPage depends on both types and client edits
        ↓
Step 5: Verification
        dotnet build          — AC-11: zero errors, zero warnings
        Reset DB + dotnet run — fresh database with new table + PT001240
        Swagger ACs           — AC-01 through AC-09
        /hipaa-check          — AC-10: COMPLIANT
```

---

## 7. Risks and Mitigations

| Risk | Likelihood | Mitigation |
|------|------------|------------|
| `health_plan_id` SERIAL values differ on non-fresh DB (AC-01, AC-02) | Medium | Run `GET /api/healthplans` first; confirm Cigna=1, Aetna=2 before Swagger tests. Note documented in spec.md Section 9. |
| NULL plan_code comparison returns ELIGIBLE when both sides are NULL | Medium | Explicit guard in controller: `member.PlanCode != null AND member.PlanCode == plan.PlanCode`. Covered by AC-03 with PT001240. |
| `onSelect` fires before `state.healthPlan` is set | Low | Impossible — step 4 is only reachable after step 3 passes `canProceed()`, which requires `state.healthPlan !== null`. |
| `EligibilityCheckResponse` import missing from `NewAuthorizationPage.tsx` | Low | Explicitly add to import statement. TypeScript compiler catches at build time (AC-11). |
| PT001240 not present after DB reset | Low | PT001240 seed row is in `init.sql` — present on every fresh DB initialisation. |
| Audit row written for HTTP 400 case | Low | HTTP 400 is returned by `[ApiController]` model validation before the action body executes — `SaveChangesAsync` is never reached. Verified by AC-06. |

---

## 8. Constitution Compliance Check

*Verify each item before this plan is approved:*

- [X] All new files follow naming conventions — CLAUDE.md section 5
      `EligibilityController.cs` → Controller (singular, intentional — documented)
      `EligibilityCheck` → Entity class with `[Table]`
      `EligibilityCheckRequest` → `[Feature]Request` record
      `EligibilityCheckResponse` → `[Feature]Response` record

- [X] Route follows pattern — CLAUDE.md section 6
      `[Route("api/[controller]")]` + `[HttpPost("check")]`
      → `POST /api/eligibility/check` (matches CLAUDE.md API surface example exactly)

- [X] No new service class; no AddScoped needed — CLAUDE.md section 7
      `PriorAuthDbContext` is already registered. `ILogger<T>` is registered
      by ASP.NET Core automatically. `Program.cs` is not modified.

- [X] EF Core LINQ only — CLAUDE.md section 2.1
      `FindAsync(patientId)`, `FindAsync(healthPlanId)`, `Add()`,
      `SaveChangesAsync()` — no raw SQL anywhere.

- [X] No PHI in ILogger — CLAUDE.md section 4.1
      Single log call: `{CorrelationId}` and `{Status}` only.
      `patientId`, member name, DOB, MemberCode, PlanCode — none logged.

- [X] No new NuGet packages — CLAUDE.md section 9
      EF Core already present. No additions.

- [X] All non-goals from spec.md section 7 absent from this plan:
      ❌ Real-time payer API — not present (DataSource="LOCAL_DB" constant only)
      ❌ Blocking submission — not present (Continue button never disabled)
      ❌ Date-based eligibility — not present (plan_code comparison only)
      ❌ Benefit-level eligibility — not present (no procedure-level logic)
      ❌ Caching — not present (FindAsync on every request)
      ❌ RBAC — not present (no auth changes)
