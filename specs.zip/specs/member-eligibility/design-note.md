# DESIGN-NOTE.md — Member Eligibility Check (Phase 1)
# Location : specs/member-eligibility/design-note.md
# Committed : YES
# Status    : DRAFT
# Author    : Kamal Gurnani | Date: 2026-06-23
# Depends on: spec.md DRAFT, risk-classification.md COMPLETE
#
# PURPOSE   : Capture technical design decisions, security and privacy
#             considerations, audit implications, and approval gates
#             BEFORE task breakdown and implementation.
# ─────────────────────────────────────────────────────────────

---

## Feature

Member Eligibility Check — Phase 1 (Local DB Lookup)

---

## Summary of Approach

The eligibility check is implemented as a single new controller action —
`EligibilityController.Check()` — that performs two EF Core point-queries
(member by `patientId`, health plan by `healthPlanId`), compares their
`plan_code` fields, writes one audit row, and returns the result. No service
class is introduced: the logic is four lines of comparison and one
`SaveChangesAsync`. Extracting a service for this would be abstraction for
its own sake (K2 — Simplicity First). Phase 1 is local database only; no
external payer API calls are made.

---

## Components Affected

### New files
| File | Purpose |
|------|---------|
| `backend/PriorAuth.API/Controllers/EligibilityController.cs` | New controller — single `[HttpPost("check")]` action |

### Modified files — Backend
| File | Change |
|------|--------|
| `backend/PriorAuth.API/Models/Entities.cs` | Add `EligibilityCheck` entity class |
| `backend/PriorAuth.API/DTOs/Dtos.cs` | Add `EligibilityCheckRequest` and `EligibilityCheckResponse` record types |
| `backend/PriorAuth.API/Data/PriorAuthDbContext.cs` | Add `DbSet<EligibilityCheck> EligibilityChecks` property |
| `database/init.sql` | Add `CREATE TABLE eligibility_checks`; add PT001240 seed member (NULL plan_code) |

### Modified files — Frontend
| File | Change |
|------|--------|
| `frontend/src/types/index.ts` | Add `EligibilityCheckRequest` and `EligibilityCheckResponse` TypeScript interfaces |
| `frontend/src/api/client.ts` | Add `api.eligibility.check()` fetch method |
| `frontend/src/pages/NewAuthorizationPage.tsx` | Step 4: call check on `onSelect`; render inline eligibility banner |

### Not touched
All existing controllers, entities, DTOs, and database tables are read-only
from this feature's perspective. No existing file has logic removed or altered.

---

## Data Handling Design

### Data flow — one request cycle

```
Agent clicks member in SearchSelect
  → onSelect fires (NewAuthorizationPage.tsx)
  → api.eligibility.check({ patientId, healthPlanId }) called
  → POST /api/eligibility/check

EligibilityController.Check(EligibilityCheckRequest req):
  1. correlationId = req.CorrelationId ?? Guid.NewGuid()
  2. member  = await _db.Members.FindAsync(req.PatientId)      ← point query
  3. plan    = await _db.HealthPlans.FindAsync(req.HealthPlanId) ← point query
  4. status  = DetermineStatus(member, plan)                   ← pure comparison
  5. audit   = new EligibilityCheck { ... }                    ← see schema below
  6. _db.EligibilityChecks.Add(audit)
     await _db.SaveChangesAsync()                              ← single commit
  7. return EligibilityCheckResponse(status, correlationId, ...)

Frontend receives response
  → renders colored inline banner below member chip
```

### PHI boundary — explicit

| PHI field | Enters system as | Used for | Stored in DB | Written to ILogger |
|-----------|-----------------|----------|--------------|--------------------|
| `patientId` | Request body field | `FindAsync(patientId)` lookup key only | ❌ No | ❌ No |
| `member.FirstName` | EF entity property | Not used — entity discarded after `plan_code` extracted | ❌ No | ❌ No |
| `member.LastName` | EF entity property | Not used — entity discarded after `plan_code` extracted | ❌ No | ❌ No |
| `member.DateOfBirth` | EF entity property | Not used | ❌ No | ❌ No |
| `member.MemberCode` | EF entity property | Not used | ❌ No | ❌ No |
| `member.PlanCode` | EF entity property | Compared to `health_plan.plan_code` — string equality only | ❌ No | ❌ No |

The `Member` entity is fetched to access `PlanCode` only. The entity object
is not passed to any logger, serializer, or audit record. It falls out of
scope after the comparison.

### Audit record schema — resolved design decision

The `eligibility_checks` table stores **no PHI**:

```sql
CREATE TABLE eligibility_checks (
    id               SERIAL       PRIMARY KEY,
    correlation_id   VARCHAR(50)  NOT NULL UNIQUE,
    eligibility_status VARCHAR(20) NOT NULL,          -- 'ELIGIBLE' | 'INELIGIBLE' | 'ERROR'
    checked_at       TIMESTAMP    NOT NULL DEFAULT NOW(),
    data_source      VARCHAR(50)  NOT NULL DEFAULT 'LOCAL_DB'
);
```

`data_source` is set to `'LOCAL_DB'` in Phase 1. Phase 2 (real-time payer
API) can write `'PAYER_API'` to the same table without a schema change.

> **⚠ Spec conflict — Section 8 must be updated before PLAN.md**
> spec.md Section 8 (resolved from OQ-01) proposed storing `patient_id`
> and `health_plan_id` as nullable columns in the audit table. This design
> note overrides that decision: neither column is stored. Rationale:
> `patient_id` is PHI (CLAUDE.md section 4.1); `health_plan_id` adds no
> audit value that `correlationId` + `eligibility_status` does not already
> provide. The `correlationId` is the sole traceability key. spec.md
> Section 8 must be corrected before PLAN.md is written.

### ILogger — what is logged

```csharp
// ONLY this — no PHI, no healthPlanId, no patientId
_logger.LogInformation("Eligibility check completed: {CorrelationId} → {Status}",
    correlationId, status);
```

Nothing else is logged on the success path. On unhandled exception, ASP.NET
Core's default exception middleware logs the exception type and message — no
request body fields reach those logs.

---

## Security / Privacy Considerations

*Source: risk-classification.md answers*

| Risk | Mitigations applied |
|------|---------------------|
| PHI in request touches the system | `patientId` used as a DB lookup key only; the full `Member` entity is never serialized, logged, or stored in the audit table |
| PHI in audit log | Audit table contains no PHI fields — `correlation_id`, `eligibility_status`, `checked_at`, `data_source` only |
| PHI in ILogger calls | Single `LogInformation` call uses `{CorrelationId}` and `{Status}` only — both non-PHI |
| New attack surface on `/api/eligibility/check` | Endpoint is `[ApiController]` with ASP.NET Core model validation; malformed or missing fields return HTTP 400 before any DB query executes |
| No auth/authorization changes | Existing middleware unchanged; endpoint inherits same access as all other `/api/` routes |
| External API calls introducing data leakage | None in Phase 1 — local DB only; no outbound network calls |

The change is classified **Medium** risk by risk-classification.md. The primary
risk driver is PHI contact, mitigated entirely by the PHI boundary design above.

---

## Audit and Observability Considerations

*Reference: CLAUDE.md section 4.1 — HIPAA compliance rules*

**What is written per check:**

| Field | Value | PHI? |
|-------|-------|------|
| `correlation_id` | Caller-supplied GUID, or `Guid.NewGuid()` | No |
| `eligibility_status` | `ELIGIBLE`, `INELIGIBLE`, or `ERROR` | No |
| `checked_at` | `NOW()` (PostgreSQL default) | No |
| `data_source` | `LOCAL_DB` (Phase 1 constant) | No |

**What is explicitly NOT written:**
- `patient_id` / `patientId` — PHI, excluded by design
- `health_plan_id` — excluded; `correlation_id` + `status` is sufficient
- Member name, DOB, MemberCode, plan code — never touch the audit path
- Full request or response body — not persisted anywhere

**Observability:** The `correlation_id` echoed in the API response allows
an operator to cross-reference a specific agent interaction with its audit
row using a single `SELECT` — without needing any PHI.

**Every check writes exactly one row** — including ERROR outcomes (member
not found, plan not found). A missing audit row for a known `correlationId`
indicates an unhandled exception (HTTP 500), which is observable via
application logs.

---

## Test Strategy

Per CLAUDE.md: no automated test suite exists in this project. Verification
is AC-based using Swagger and direct DB queries.

| AC | Verification method | Notes |
|----|---------------------|-------|
| AC-01 (ELIGIBLE) | Swagger POST | PT001234 + healthPlanId=1 |
| AC-02 (INELIGIBLE mismatch) | Swagger POST | PT001234 + healthPlanId=2 |
| AC-03 (INELIGIBLE NULL plan_code) | Swagger POST | PT001240 + healthPlanId=1 |
| AC-04 (ERROR member not found) | Swagger POST | PT999999 + healthPlanId=1 |
| AC-05 (ERROR plan not found) | Swagger POST | PT001234 + healthPlanId=99999 |
| AC-06 (HTTP 400 + no audit row) | Swagger POST + `SELECT count(*) FROM eligibility_checks` | Verify row count unchanged |
| AC-07 (auto-generate correlationId) | Swagger POST | Omit field, inspect response |
| AC-08 (echo correlationId) | Swagger POST | Provide known GUID, verify echo |
| AC-09 (audit row written) | `SELECT * FROM eligibility_checks WHERE correlation_id = '...'` | Run after each of AC-01–05 |
| AC-10 (no PHI in logs) | `/hipaa-check` skill | Run after implementation complete |
| AC-11 (zero build warnings) | `dotnet build` | Run after all backend changes |

**HIPAA scan:** `/hipaa-check` must return COMPLIANT before PR is raised.
This is non-negotiable per risk-classification.md (PHI involved = YES).

**Test data:** All test data is synthetic seed data from `init.sql`.
No real patient records are used. PT001240 is a synthetic member added
solely for this feature's AC-03 coverage.

**Frontend behaviors verified manually (add to EVAL.md):**
- After INELIGIBLE result: "Continue →" button remains enabled
- After ERROR result: "Continue →" button remains enabled
- Member chip cleared (✕ click): eligibility banner disappears, no API call
- Fetch failure (backend unreachable): amber warning shown, Continue enabled
- Response arrives in < 500ms under normal load

---

## Rollback / Failure Handling

### Rollback approach — additive only

Every change in this feature is a pure addition. No existing table, entity,
DTO, controller, or page is modified in a way that breaks existing behavior
if the new code is removed.

| Change | Rollback action |
|--------|----------------|
| `eligibility_checks` table | `DROP TABLE eligibility_checks;` in init.sql |
| `EligibilityCheck` entity | Delete class from `Entities.cs` |
| `DbSet<EligibilityCheck>` | Remove property from `PriorAuthDbContext.cs` |
| `EligibilityController.cs` | Delete file |
| DTO records in `Dtos.cs` | Remove two record declarations |
| Frontend `types/index.ts` | Remove two interface declarations |
| Frontend `api/client.ts` | Remove `eligibility` namespace |
| Frontend `NewAuthorizationPage.tsx` | Remove onSelect hook + banner JSX |
| PT001240 seed row | Remove INSERT from init.sql |

Rolling back requires re-running `database/init.sql` against a fresh DB
(consistent with the project's no-migrations pattern).

### Runtime failure handling

| Failure mode | Behaviour |
|--------------|-----------|
| DB unavailable | EF throws; ASP.NET Core returns HTTP 500; no audit row written; frontend (Flow 5) shows generic amber warning |
| `patientId` not found in members table | Status = ERROR, `errorCode` = "ERR-MBR-001"; audit row written with NULL-equivalent intent captured in status |
| `healthPlanId` not found in health_plans | Status = ERROR, `errorCode` = "ERR-PLAN-001"; audit row written |
| Eligibility result is INELIGIBLE or ERROR | Wizard is not blocked — advisory only (FR-05) |
| Frontend fetch timeout / network failure | Amber "unavailable" warning shown; no API call retry; agent can proceed |

The eligibility check is a **non-blocking read + audit-write** operation.
Its failure does not affect PA request creation in any way.

---

## Open Questions

All open questions from spec.md are resolved. One spec correction is required
before PLAN.md:

| Item | Action required |
|------|----------------|
| spec.md Section 8 — audit table includes `patient_id` and `health_plan_id` | **Must be corrected.** Remove both columns. Final schema is: `id`, `correlation_id`, `eligibility_status`, `checked_at`, `data_source`. This design note is the authoritative source. |
| AC-03 "any valid healthPlanId" | **Must be made concrete.** Replace with "healthPlanId=1" before PLAN.md. |
| PT001240 seed data — full column values not specified | **Must be added to spec.md Section 9.** Proposed: `first_name='Test'`, `last_name='NoPlan'`, all nullable fields NULL except required NOT NULL columns. |

---

## Approval Gates

*Derived from risk-classification.md — Medium risk, PHI contact confirmed*

- [X] Tech lead review — required per risk-classification.md
- [X] Security review — required: risk question "Does the change involve PHI?" = YES
- [ ] Privacy review — PHI contact is mitigated by design (no storage, no logging); deferring to security review gate above
- [ ] Domain SME review — not required: no clinical, claims, billing, or payment logic
- [ ] QA / validation review — required per risk-classification.md; completed via AC-based Swagger testing + /hipaa-check
- [ ] Product owner review — required per risk-classification.md; advisory-only behaviour must be confirmed acceptable
