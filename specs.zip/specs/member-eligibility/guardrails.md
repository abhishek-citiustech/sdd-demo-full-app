# GUARDRAILS.md — Member Eligibility Check (Phase 1)
# Location : specs/member-eligibility/guardrails.md
# Committed: YES
# Status   : DRAFT
# Author   : Kamal Gurnani  |  Date: 2026-06-23
# Purpose  : Hard clinical/regulatory boundaries the agent must always or never
#            cross for the Member Eligibility Check feature. Encoded before
#            implementation begins. A guardrail that can be bypassed by calling
#            the API directly instead of going through the UI is not a guardrail.
# See also : spec.md section 7 (Non-Goals) — every NEVER rule traces back to one.
#            design-note.md (Security/Privacy, Audit and Observability) — every
#            MUST rule traces to a decision made there.
# ─────────────────────────────────────────────────────────────

---

## 1. MUST — The Agent Must Always Do This

| ID    | Guardrail | Trigger Condition | Failure Behaviour (what the agent does / what the user sees) | Source |
|-------|-----------|-------------------|--------------------------------------------------------------|--------|
| G-M01 | Verify both the member record AND the health plan record exist in the local DB before comparing `plan_code` values. If either is missing, return `status=ERROR` with the appropriate error code — never silently return ELIGIBLE. | Every call to `EligibilityController.Check()` that passes model validation | Returns HTTP 200 `{ status: "ERROR", errorCode: "ERR-MBR-001" }` or `"ERR-PLAN-001"` as appropriate; one audit row is written with `eligibility_status=ERROR`; no exception is surfaced to the caller | design-note.md "Data Handling Design" step 2–4; spec.md FR-04, AC-04, AC-05 |
| G-M02 | Generate a `correlationId` (`Guid.NewGuid()`) server-side if the request body does not supply one. The generated value must be used in both the audit row and the response before any DB query executes. | Every request where `req.CorrelationId` is null or absent | If `correlationId` is not populated before the audit write, the audit row cannot be cross-referenced with the API response; code review blocks any PR where `correlationId` assignment comes after the DB query | design-note.md "Data Handling Design" step 1; spec.md FR-07, AC-07, AC-08 |
| G-M03 | Write exactly one row to `eligibility_checks` per completed check, for all three outcome statuses — ELIGIBLE, INELIGIBLE, and ERROR. The row must contain: `correlation_id`, `eligibility_status`, `checked_at`, `data_source`. A check that produces no audit row is a silent failure. | Every request that passes HTTP 400 model validation (i.e., every call that reaches the controller body) | If `SaveChangesAsync` fails, EF throws; ASP.NET Core returns HTTP 500; the unhandled-exception path is logged at framework level. Partial audit writes (row without all four columns populated) are prevented at the DB schema level via `NOT NULL` constraints | design-note.md "Audit and Observability"; spec.md FR-06, AC-06, AC-09 |
| G-M04 | The `eligibility_checks` audit row must contain only the four approved columns: `correlation_id`, `eligibility_status`, `checked_at`, `data_source`. No other field — in particular no `patient_id`, `health_plan_id`, or any member attribute — may be added to the `EligibilityCheck` entity or the `CREATE TABLE` statement. | The `EligibilityCheck` entity instantiation and the `database/init.sql` schema definition | Any addition of a PHI column to the audit schema causes `/hipaa-check` to return FAIL; the PR is blocked at review | design-note.md "Audit record schema"; CLAUDE.md §4.1 |
| G-M05 | Return HTTP 400 for requests missing `patientId`, `healthPlanId`, or carrying a non-empty but malformed `correlationId` GUID. No audit row is written for HTTP 400 responses. | ASP.NET Core model validation fires before the controller action body executes | HTTP 400 with model-validation error body; controller body never reached; `SELECT count(*) FROM eligibility_checks` is unchanged for that attempt | design-note.md "Security / Privacy"; spec.md §4.4, AC-06 |

---

## 2. NEVER — The Agent Must Refuse, Regardless of What Is Asked

| ID    | Guardrail | Trigger Condition | Failure Behaviour (what the agent does / what the user sees) | Source |
|-------|-----------|-------------------|--------------------------------------------------------------|--------|
| G-N01 | Never make any outbound network call or real-time payer API call inside `EligibilityController`. Phase 1 is local DB lookup only — two `FindAsync` point queries, nothing else. | Any code path inside `EligibilityController.cs` that introduces an `HttpClient`, `IHttpClientFactory`, or external service dependency | PR is blocked at code review; `dotnet build` succeeds (no compile-time enforcement) but any outbound call introduces latency, a new attack surface, and a Phase 2 scope violation. Reviewer must verify no outbound dependency is wired in `Program.cs` | spec.md §7 "Real-time payer API integration" |
| G-N02 | Never disable, hide, or conditionally gate the wizard "Continue →" button based on an eligibility result — ELIGIBLE, INELIGIBLE, ERROR, or loading. The result is advisory only. | Any React code on wizard step 4 that reads `eligibilityStatus` and sets `disabled` on the Continue button | If Continue is gated: agent cannot proceed with a valid PA request when the member is INELIGIBLE; FR-05 is violated; AC-02, AC-03, AC-04, and AC-05 manual tests show button is disabled. Frontend must pass the eligibility banner as display-only | spec.md §7 "Blocking PA submission on INELIGIBLE or ERROR"; spec.md FR-05 |
| G-N03 | Never include PHI field values in any `ILogger` call at any log level — including `LogDebug`, `LogTrace`, and exception messages. The only values permitted in log calls are `correlationId` (a non-PHI GUID) and `status` (a non-PHI enum string). PHI fields covered: `patientId`, `firstName`, `lastName`, `dateOfBirth`, `memberCode`, `phone`, `emailAddress`, `addressLine1`, `addressLine2`, `city`, `state`, `zipCode`. See hipaa-check skill (section 5) for the canonical list. | Any `ILogger` call inside `EligibilityController.cs` that has access to the member entity, the `EligibilityCheckRequest`, or a request body field | `/hipaa-check` returns FAIL; PR is blocked. The log line must read: `"Eligibility check completed: {CorrelationId} → {Status}"` with no additional structured parameters | spec.md §7 / FR-08; design-note.md "ILogger — what is logged"; CLAUDE.md §4.1 |
| G-N04 | Never store `patient_id`, `health_plan_id`, member name, member `plan_code` value, or any other PHI attribute in the `eligibility_checks` table, in any EF entity property mapped to that table, or in any in-process object that is then persisted. | The `EligibilityCheck` entity class definition and the `database/init.sql` `CREATE TABLE eligibility_checks` statement | If a PHI column appears in the schema diff: `/hipaa-check` returns FAIL; PR is blocked. The `Member` entity is fetched solely to read `PlanCode` for the comparison; it must not be passed to the audit object or any serializer | design-note.md "Audit record schema" / "PHI boundary"; spec.md FR-06 |
| G-N05 | Never implement date-based eligibility — no effective-date, termination-date, or enrollment-period comparison may appear in `EligibilityController` or `EligibilityCheckRequest`. | Any code change that adds a date field to `EligibilityCheckRequest`, or adds a date filter to the member/plan query | PR is blocked at code review. The `eligibility_checks` schema and `EligibilityCheckRequest` DTO have no date fields; adding one requires a schema change that will be caught in `init.sql` review | spec.md §7 "Date-based eligibility" |
| G-N06 | Never implement benefit-level or procedure-specific eligibility — no procedure code, benefit tier, service type, or quantity comparison may appear in the eligibility check logic. | Any code change that adds a `procedureCode`, `serviceType`, or benefit field to `EligibilityCheckRequest` or the comparison logic | PR is blocked at code review. `EligibilityCheckRequest` accepts only `patientId`, `healthPlanId`, and `correlationId`; any additional parameter is a scope violation | spec.md §7 "Benefit-level or procedure-specific eligibility" |
| G-N07 | Never cache an eligibility result — no in-memory dictionary, `IMemoryCache`, session store, or client-side state keyed by `patientId`/`healthPlanId` may be used to skip a DB query. Every check must execute the two `FindAsync` queries and write an audit row. | Any introduction of a cache layer between the frontend call and the DB query, including React state reuse across member selections | If a cached result is returned: no audit row is written for that check (AC-09 fails on replay); the `eligibility_checks` table row count does not increment. Detecting this requires running AC-09 twice for the same `patientId`/`healthPlanId` pair and confirming two distinct rows with different `correlation_id` values | spec.md §7 "Caching of eligibility results" |

---

## 3. Adversarial Test Log
<!-- No controller exists yet. Fill this section after EligibilityController.cs is implemented.
     Run the guardrail-red-team subagent against the controller, or test by hand per the
     instructions in the template. Do not raise a PR with an open BYPASSED result. -->

| Guardrail ID | Adversarial Attempt (what you tried) | Result | Tested By / Date |
|--------------|--------------------------------------|--------|------------------|
| G-N01 | | | |
| G-N02 | | | |
| G-N03 | | | |
| G-N04 | | | |│ G-N04 │ BYPASSED — active violation │ patient_id and health_plan_id are stored in every audit row │ Kamal Gurnani / 2026-06-23 |
| G-N05 | | | |
| G-N06 | | | |
| G-N07 | | | |

---

## 4. Guardrail ↔ Spec Traceability

### 4.1 Non-Goals → NEVER guardrails

| spec.md §7 Non-Goal | Guardrail ID | Notes |
|---------------------|--------------|-------|
| Real-time payer API integration | G-N01 | Enforced by code review — no `HttpClient` in EligibilityController |
| Blocking PA submission on INELIGIBLE or ERROR | G-N02 | Enforced at runtime — Continue button must stay enabled regardless of `eligibilityStatus` |
| Date-based eligibility | G-N05 | Schema-enforced: no date fields in `EligibilityCheckRequest` or `eligibility_checks`; also enforced by code review |
| Benefit-level or procedure-specific eligibility | G-N06 | Schema-enforced: no procedure/benefit field in `EligibilityCheckRequest`; also enforced by code review |
| Caching of eligibility results | G-N07 | Detected by running AC-09 twice for the same pair and asserting two distinct `correlation_id` rows |
| Role-based access control on the eligibility endpoint | — | No guardrail needed: scope limit with no enforceable runtime behaviour. The endpoint inherits the same access control as all existing `/api/` routes (none in Phase 1). No new auth code is introduced, so there is no code path to guard. RBAC can be added in a future phase at that point. |

### 4.2 design-note.md Decisions → MUST guardrails

| design-note.md Decision | Guardrail ID |
|--------------------------|--------------|
| "Verify both member and health plan exist; return ERROR if either is missing — never silently return ELIGIBLE" | G-M01 |
| "correlationId = req.CorrelationId ?? Guid.NewGuid() — assigned before any DB query" | G-M02 |
| "Every check writes exactly one audit row — including ERROR outcomes" | G-M03 |
| "Audit record contains only: correlation_id, eligibility_status, checked_at, data_source — no PHI columns" | G-M04 |
| "Malformed or missing fields return HTTP 400 before any DB query executes; no audit row written" | G-M05 |
| "Single LogInformation call uses {CorrelationId} and {Status} only — no PHI in ILogger" | G-N03 |
| "patient_id and health_plan_id excluded from eligibility_checks by design" | G-N04 |

---

## 5. Compliance Guardrails — Cross-Reference Only

Do not duplicate the PHI field list here. The hipaa-check skill is the single
source of truth for PHI / credential / audit rules.

| Guardrail ID | hipaa-check Coverage |
|--------------|----------------------|
| G-N03 | PHI-in-logs check (hipaa-check Step 1) — ILogger call must contain correlationId + status only |
| G-N04 | PHI-in-audit-table check (hipaa-check Step 1) — `eligibility_checks` schema must have zero PHI columns |
