# EVAL_SET.md — Member Eligibility Check (Phase 1)
# Location : specs/member-eligibility/eval-set.md
# Committed: YES
# Status   : DRAFT
# Author   : Kamal Gurnani  |  Date: 2026-06-24
# Purpose  : Define what "correct" looks like — BEFORE generation starts.
#            Execute Wednesday/Thursday via the eval-run skill — results are
#            recorded in EVAL.md section 4, not in this file. This file does
#            not change once VALIDATED, except to append new cases (section 4).
# See also : spec.md §3 (Acceptance Criteria) — every case below traces to an
#            AC, a Guardrail ID, or both. design-note.md "Test Strategy" — edge
#            cases named there are represented here.
# ─────────────────────────────────────────────────────────────

---

## 1. Eval Statement

The Member Eligibility Check is performing correctly when it returns ELIGIBLE,
INELIGIBLE, or ERROR with the right error code (null for ELIGIBLE/INELIGIBLE;
ERR-MBR-001 or ERR-PLAN-001 for ERROR) and the resulting audit row in
`eligibility_checks` contains no PHI column; it has failed when it returns any
other status, throws an unhandled exception, returns a non-200 HTTP status for
a valid request, or any PHI field value appears in an ILogger call or in the
audit row.

---

## 2. Eval Cases

| ID    | Scenario | Input | Expected Output | Known Failure Mode | Traces To | Validated By |
|-------|----------|-------|-----------------|-------------------|-----------|--------------|
| EV-01 | Standard — plan codes match, member and health plan both exist | `POST /api/eligibility/check` · `patientId="PT001234"` (plan_code=CIGNA) · `healthPlanId=1` (Cigna Health, plan_code=CIGNA) | HTTP 200 · `status="ELIGIBLE"` · `correlationId` is a non-empty GUID · `errorCode=null` · `errorMessage=null` · One row inserted in `eligibility_checks` with `eligibility_status="ELIGIBLE"` | None — happy path; failure here means the core comparison logic is broken | AC-01, FR-02 | |
| EV-02 | Standard — plan codes do not match, both records exist | `POST /api/eligibility/check` · `patientId="PT001234"` (plan_code=CIGNA) · `healthPlanId=2` (Aetna Better Health, plan_code=AETNA) | HTTP 200 · `status="INELIGIBLE"` · `errorCode=null` · `errorMessage=null` · One row inserted with `eligibility_status="INELIGIBLE"` | Code may return `status="ERROR"` instead of `"INELIGIBLE"` when a mismatch is found; code may throw if the string comparison is not null-safe | AC-02, FR-03 | |
| EV-03 | Edge — member record does not exist | `POST /api/eligibility/check` · `patientId="PT999999"` (no matching row in `members`) · `healthPlanId=1` (valid) | HTTP 200 · `status="ERROR"` · `errorCode="ERR-MBR-001"` · `correlationId` is a non-empty GUID · One row inserted with `eligibility_status="ERROR"` | Code may return HTTP 404 or HTTP 500 instead of HTTP 200 with `status="ERROR"`; audit row may be skipped when member is not found; correlationId may not be generated before the lookup, leaving the audit row without a traceability key | AC-04, G-M01 | |
| EV-04 | Edge — member exists but `plan_code` is NULL | `POST /api/eligibility/check` · `patientId="PT001240"` (`plan_code=NULL` — Test NoPlan seed record) · `healthPlanId=1` (Cigna Health, plan_code=CIGNA) | HTTP 200 · `status="INELIGIBLE"` · `errorCode=null` · One row inserted with `eligibility_status="INELIGIBLE"` | NULL `plan_code` may cause a `NullReferenceException` in the string comparison, producing an unhandled HTTP 500; code may return `status="ERROR"` instead of `"INELIGIBLE"` — a NULL plan_code is a plan mismatch (FR-03), not a missing-record ERROR | AC-03, FR-03 | |
| EV-05 | Guardrail — audit row contains no PHI, ILogger contains no PHI | Run EV-01 input · then `SELECT * FROM eligibility_checks WHERE correlation_id = '<returned correlationId>'` · then inspect application log output for that request | Audit row columns: `correlation_id` (GUID), `eligibility_status` ("ELIGIBLE"), `checked_at` (timestamp), `data_source` ("LOCAL_DB") — no `patient_id` column, no `health_plan_id` column, no member attribute · ILogger output for that request contains only `{CorrelationId}` and `{Status}` — no patientId, firstName, lastName, dateOfBirth, memberCode, phone, emailAddress, addressLine value appears anywhere in the log line | PHI column (e.g. `patient_id`) accidentally added to `EligibilityCheck` entity and persisted; ILogger call includes the member entity or the full request body object; plan_code value (a quasi-identifier) logged during the comparison step | AC-09, AC-10, FR-06, FR-08, G-N03, G-N04 | |

---

## 3. Run Cadence

- [ ] Before this feature's PR is raised (baseline run — results go in EVAL.md section 4)
- [ ] After every change to this feature's controller, entity, or frontend eligibility call
- [ ] After every Claude / Anthropic model version change used on this project
- [ ] Quarterly, alongside the CLAUDE.md / GUARDRAILS.md review

A model update is not a patch. Re-run the full set — do not assume backward
compatibility with a previous run's results.

---

## 4. Production Feedback Loop

Once shipped, real failures are added here as new eval cases — not filed
separately and forgotten. This section grows; sections 1–3 above do not
change once VALIDATED.

| Date | What Broke In Production | New Eval Case ID Added |
|------|--------------------------|------------------------|
| | | |
